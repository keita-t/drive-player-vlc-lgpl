#! /bin/sh
set -e

LIBVLCJNI_SRC_DIR="$(cd "$(dirname "$0")"; pwd -P)/.."
PATCHES_DIR=$LIBVLCJNI_SRC_DIR/libvlc/patches
#############
# FUNCTIONS #
#############

diagnostic()
{
    echo "$@" 1>&2;
}

fail()
{
    diagnostic "$1"
    exit 1
}

# Try to check whether a patch file has already been applied to the current directory tree
# Warning: this function assumes:
# - The patch file contains a Message-Id header. This can be generated with `git format-patch --thread ...` option
# - The patch has been applied with `git am --message-id ...` option to keep the Message-Id in the commit description
check_patch_is_applied()
{
    patch_file=$1
    diagnostic "Checking presence of patch $1"
    message_id=$(grep -E '^Message-Id: [^ ]+' "$patch_file" | sed 's/^Message-Id: \([^\ ]+\)/\1/')
    if [ -z "$message_id" ]; then
        diagnostic "Error: patch $patch_file does not contain a Message-Id."
        diagnostic "Please consider generating your patch files with the 'git format-patch --thread ...' option."
        diagnostic ""
        exit 1
    fi
    if [ -z "$(git log --grep="$message_id")" ]; then
        diagnostic "Cannot find patch $patch_file in tree, aborting."
        diagnostic "There can be two reasons for that:"
        diagnostic "- you forgot to apply the patch on this tree, or"
        diagnostic "- you applied the patch without the 'git am --message-id ...' option."
        diagnostic ""
        exit 1
    fi
}

VLC_TESTED_HASH=66455a98c8c515796b4a192acaa125c5d68c76c8
VLC_REPOSITORY=https://code.videolan.org/videolan/vlc.git
VLC_BRANCH=3.0.x

RESET=0
while [ $# -gt 0 ]; do
    case $1 in
        help|--help|-h)
            echo "Use -b to bypass libvlc source checks (vlc custom sources)"
            echo "  --vlcgit <vlc_git_url> (default $VLC_TESTED_HASH)"
            echo "  --vlchash <vlc_git_hash> (default $VLC_REPOSITORY)"
            echo "  --vlcbranch <branch_name> (default $VLC_BRANCH)"
            exit 0
            ;;
        --reset)
            RESET=1
            ;;
        --vlcgit)
            VLC_REPOSITORY=$2
            shift
            ;;
        --vlchash)
            VLC_TESTED_HASH=$2
            shift
            ;;
        --vlcbranch)
            VLC_BRANCH=$2
            shift
            ;;
        -b)
            BYPASS_VLC_SRC_CHECKS=1
            ;;
        *)
            diagnostic "$0: Invalid option '$1'."
            diagnostic "$0: Try --help for more information."
            exit 1
            ;;
    esac
    shift
done

####################
# Fetch VLC source #
####################

if [ ! -d "vlc" ]; then
    diagnostic "VLC sources: not found, cloning"
    git clone "${VLC_REPOSITORY}" vlc -b ${VLC_BRANCH} --single-branch || fail "VLC sources: git clone failed"
    cd vlc
    diagnostic "VLC sources: resetting to the VLC_TESTED_HASH commit (${VLC_TESTED_HASH})"
    git reset --hard ${VLC_TESTED_HASH} || fail "VLC sources: VLC_TESTED_HASH ${VLC_TESTED_HASH} not found"
    diagnostic "VLC sources: applying custom patches"
    # Keep Message-Id inside commits description to track them afterwards
    git am --message-id $PATCHES_DIR/*.patch || fail "VLC sources: cannot apply custom patches"
    cd ..
else
    diagnostic "VLC source: found sources, leaving untouched"
fi
if [ "$BYPASS_VLC_SRC_CHECKS" = 1 ]; then
    diagnostic "VLC sources: Bypassing checks (required by option)"
elif [ $RESET -eq 1 ]; then
    cd vlc
    git reset --hard ${VLC_TESTED_HASH} || fail "VLC sources: VLC_TESTED_HASH ${VLC_TESTED_HASH} not found"
    for patch_file in $PATCHES_DIR/*.patch; do
        git am --message-id $patch_file
        check_patch_is_applied "$patch_file"
    done
    cd ..
else
    diagnostic "VLC sources: Checking VLC_TESTED_HASH and patches presence"
    diagnostic "NOTE: checks can be bypass by adding '-b' option to this script."
    cd vlc
    git cat-file -e ${VLC_TESTED_HASH} 2> /dev/null || \
        fail "Error: Your vlc checkout does not contain the latest tested commit: ${VLC_TESTED_HASH}"
    for patch_file in $PATCHES_DIR/*.patch; do
        check_patch_is_applied "$patch_file"
    done
    cd ..
fi
