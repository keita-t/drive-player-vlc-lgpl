/*****************************************************************************
 * MediaInput.java
 *****************************************************************************
 * Copyright © 2026 Drive Player authors
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

package org.videolan.libvlc;

import java.nio.ByteBuffer;

/**
 * The bytes of a {@link Media} served by the application, read through these callbacks rather than
 * opened by libVLC from a path, a location or a file descriptor.
 *
 * libVLC calls every method from its own threads, one call at a time for one opening of the media,
 * and waits for each to return: a call that blocks holds up that playback, including stopping it.
 * The input is kept until the native media is freed, which may be after {@link Media#release()}
 * when a player still holds it, and may be opened again by a later playback of the same media.
 */
public interface MediaInput {

    /**
     * The media is being opened; the next read starts at offset 0.
     *
     * @return the total size in bytes, or a negative value if the input cannot be opened
     */
    long open();

    /**
     * Fill {@code buffer}, from its position up to its limit, with the next bytes of the media.
     * The buffer wraps libVLC's own memory and is valid only during this call.
     *
     * @return the number of bytes written, 0 at the end of the media, or a negative value on error
     */
    int read(ByteBuffer buffer);

    /**
     * Continue reading at {@code offset}.
     *
     * @return whether the next read starts there
     */
    boolean seek(long offset);

    /** The opening of the media has ended. */
    void close();
}
