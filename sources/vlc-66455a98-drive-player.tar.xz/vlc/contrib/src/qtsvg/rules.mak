# Qt

QTSVG_VERSION := 5.6.3
QTSVG_URL := https://download.qt.io/archive/qt/5.6/$(QTSVG_VERSION)/submodules/qtsvg-opensource-src-$(QTSVG_VERSION).tar.xz

DEPS_qtsvg += qt $(DEPS_qt)

ifdef HAVE_WIN32
PKGS += qtsvg
endif

ifeq ($(call need_pkg,"Qt5Svg"),)
PKGS_FOUND += qtsvg
endif

$(TARBALLS)/qtsvg-$(QTSVG_VERSION).tar.xz:
	$(call download_pkg,$(QTSVG_URL),qt)

.sum-qtsvg: qtsvg-$(QTSVG_VERSION).tar.xz

qtsvg: UNPACK_DIR=qtsvg-opensource-src-$(QTSVG_VERSION)
qtsvg: qtsvg-$(QTSVG_VERSION).tar.xz .sum-qtsvg
	$(UNPACK)
	$(APPLY) $(SRC)/qtsvg/0001-Force-the-usage-of-QtZlib-header.patch
	$(APPLY) $(SRC)/qtsvg/0001-QSvgFont-Initialize-used-member-remove-unused.patch
	# use up to date system zlib
	sed -i -e 's,<QtZlib/,<,' $(UNPACK_DIR)/src/svg/qsvgtinydocument.cpp
	$(MOVE)

.qtsvg: qtsvg
	cd $< && $(PREFIX)/bin/qmake
	# Make && Install libraries
	+$(MAKE) -C $< sub-src
	+$(MAKE) -C $< sub-src-install_subtargets
	mv $(PREFIX)/plugins/iconengines/libqsvgicon.a $(PREFIX)/lib/
	mv $(PREFIX)/plugins/imageformats/libqsvg.a $(PREFIX)/lib/
	cd $(PREFIX)/lib/pkgconfig; sed -i \
		-e 's/d\.a/.a/g' \
		-e 's/-lQt\([^ ]*\)d/-lQt\1/g' \
		-e '/Libs:/  s/-lQt5Svg/-lqsvg -lqsvgicon -lQt5Svg/ ' \
		Qt5Svg.pc
	touch $@
